import java.awt.*;
import java.awt.image.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import java.awt.Graphics;

public class Card
{
  //fields
    //variables
    // outside methods
    // create instance variables - attributes - store info abt obeject
      // variable to store type as string
        public String type;
        private int value;
        private int  typeValue;
        private String file;
      // variable to store number as integer 
  //constructor(s)
  // default constructor - SPECIAL constructor
  public Card()
  {
    type = "Fire";
    value = 1;
    typeValue = 20;
    file = "img/F1.jpg";
  }

  public Card(String type, int value, int typeValue, String file)
  {
    this.type = type;
    this.value = value;
    this.typeValue=typeValue;
    this.file = "img/" + file;
  }

  //methods - what kind of methods should go into a card?

  //methods - getters (Accessers)

  public String getType()
  {
    return type;
  }
  public int getvalue()
  {
    return value;
  }
  public int gettypeValue()
  {
    return typeValue;
  }

  
  //methods - setters (modifyers)
  public void setType (String newType)
  {
    type = newType;
  }
  public void setvalue (int newvalue)
  {
    value=newvalue;
  }
  public void setvalueType (int newtypeValue)
  {
    typeValue=newtypeValue;
  }
  public String toString()
  {
    return value + " of " + type;
  }

//Be able to compare first card of one player with one card of other player
 public Card compareTo (Card anotherCard)
  {

    if (this.gettypeValue()==anotherCard.gettypeValue())
    {
      if (this.getvalue()>anotherCard.getvalue())
      {
        return this;
      }
      else if (this.getvalue()>anotherCard.getvalue())
      {
        return anotherCard ; 
      }
    }
    else
    {
      if ( this.getType()=="Ice"&&anotherCard.getType()=="Fire")
      {
          return anotherCard;
      }
      else if ( this.getType()=="Ice"&&anotherCard.getType()=="Water")
      {
        return this;
      }
      else if (this.getType()=="Water"&&anotherCard.getType()=="Fire")
      {
        return this;
      }
      else if (this.getType()=="Water"&&anotherCard.getType()=="Ice")
      {
        return anotherCard;
      }
      else if (this.getType()=="Fire"&&anotherCard.getType()=="Water")
      {
        return anotherCard;
      }
      else if (this.getType()=="Fire"&&anotherCard.getType()=="Ice")
      {
        return this;
      }
    }
    return this;
  }

public void draw(Graphics g, int x, int y)
  {
    Image img = null;
    try
    {
			img = ImageIO.read(new File(file));
      img = img.getScaledInstance(61,82,Image.SCALE_SMOOTH);
		} 
    catch (IOException e)
    {
			e.printStackTrace();
		}
    
    System.out.println("Drawing " + this);
    g.drawImage(img,x, y, null);

  }
}