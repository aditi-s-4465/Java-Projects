import java.util.*;
public class Deck
{
  //fields - instance variable
    // array list to store collection of things
    private ArrayList <Card> deck;
  

  //constructor(s)
  public Deck()
  {
    deck = new ArrayList <Card> ();
    setTheDeck();
  }

  //methods - what kind of methods should go into a deck?
  // shuffle
  // deal 
  // order

  //methods - getters

  //methods - setters
  public void setTheDeck ()
  {
    String [] types = {"Fire","Water","Ice"};
    int [] values = {1,2,3,4,5,6,7,8,9,10};
    int [] typeValues = {20,40,80};

    for (String type: types)
    {
      for (int value:values)
      {
        if (type.equals("Fire"))
        {
          deck.add(new Card(type,value,typeValues[0], "" + type.charAt(0)+value + ".jpg"));
        }
        if (type.equals("Water"))
        {
          deck.add(new Card(type,value,typeValues[1],"" + type.charAt(0)+value + ".jpg"));
        }
        if (type.equals("Ice"))
        {
          deck.add(new Card(type,value,typeValues[2],"" + type.charAt(0)+value + ".jpg"));
        }
      }
      }
  }

 public Card getACard() //get a random card REMOVE & return card
  {
    int index = (int)(Math.random() * deck.size());
    return deck.remove(index); //RETURN WHAT WAS REMOVED
  }

  public void shuffle()
  {
    
  }

  public void addCard(Card aCard)
  {
    deck.add(aCard);
  }

  //tostring?
  public String toString()
  {
    String deckString = "";
    for (Card myCard: deck)
    {
      deckString+=myCard.toString()+"\n";
    }
    return deckString;
  }
  
  
}