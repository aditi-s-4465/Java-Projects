import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
class Main {
  private static int numRepaints = 0;
  private static ArrayList <Card> myCards = new ArrayList <Card> ();
  private static Player aPlayer = new Player("Person");
  private static Player bPlayer = new Player("Computer");
  private static Deck myDeck = new Deck();

  public static void main(String[] args) {

   /*System.out.println(myDeck);
   *System.out.println("Card: "+myDeck.getACard());
   Deck player1Deck = new newPlayerDeck(myDeck);*/
   // System.out.println(player1Deck);

   /*Player player1 = new Player("Aditi");
   System.out.println(player1.getName());
   Player player2 = new Player("Comp");
   System.out.println(player2.getName());*/

    //Be able to deal a certain number of cards to the players
   for(int i = 1; i <= 7; i++)
    {
      aPlayer.addcard(myDeck.getACard());
      bPlayer.addcard(myDeck.getACard());
    }

   // Be able to collect used cards (like a discard pile or add to another players hand)
    /*myDeck.addCard(player1.removeCard(0));
    *System.out.println(player1);
    *System.out.println(myDeck);

    System.out.println(myDeck.getACard().compareTo(myDeck.getACard()));*/

   // initCards(); //Set up cards -> maybe want to set up players instead? Make sure to look at changes made to Deck and Card class for how I added file name based on face/suit rather than literally typing like in the example below

    
    
    
    init(); //set up panel

    //aPlayer.addcard(new Card("Water", 1, 40, "W1.jpg")); //"deal" cards to player
  
  }

 /* private static void initCards()
  {
   myCards.add(new Card("Water", 1, 40, "W1.jpg"));
   myCards.add(new Card("Ice", 5, 80, "I5.jpg"));
  }*/
  
  private static void init() {
    JFrame frame = new JFrame("Card Game Board");

		JPanel panel = new JPanel() {
			/** this is a super-important method when working with
			 * javax swing graphics. All drawing is invoked from here.
			 */
			public void paintComponent(Graphics g) {
				super.paintComponent(g);// basically clears the canvas
				numRepaints++;
				System.out.println("painting!! "+numRepaints);
				drawStuff(g);
			}
		};
    
		panel.setBackground(new Color(100, 220, 100));
		panel.setPreferredSize(new Dimension(800, 600));
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(panel);
		frame.pack();
		frame.setVisible(true);
	}

  protected static void drawStuff(Graphics g) 
  {
    //Going to traverse my cards and draw them

    //aCard.draw(g, 100, 100);



    //What if I want to "print players?"
    aPlayer.draw(g,100,100);
    bPlayer.draw(g,100,200);

 
  }


}