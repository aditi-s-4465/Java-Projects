import java.util.*;

import java.awt.Graphics;
import java.awt.Color;

public class Player
{
  private String name;
  private ArrayList <Card> hand;

  public Player()
  {
    name = "Player";
    hand = new ArrayList <Card> ();
  }

  public Player(String name)
  {
    this.name = name;
    hand = new ArrayList <Card> ();
  }

  public String getName()
  {
    return name;
  }

  public void addcard(Card aCard)
  {
    hand.add(aCard);
  }
  public Card removeCard (int index)
  {
    return hand.remove(index);
  }

  public String toString()
  {
    String info = "";
    info+="Name:"+name + "\n";
    for (Card myCard: hand)
    {
     info+= myCard.toString()+"\n";
    }
    return info;
  }

  public void draw(Graphics g, int x, int y)
  {
    g.setColor(Color.black);
    g.drawString(name, x, y);
    for(Card aCard: hand)
    {
      aCard.draw(g,x+10,y+10);
      x+=50;
     // y+=20;
    }
  }
}