import kareltherobot.*;
import java.util.*;
import java.lang.Math.*;


public class Main implements Directions{
  
  // Leave this alone!!
  String lastTurn="N";
  public static void main(String[] args) {
    new Main().start();
  }

  public void start(){
  Scanner in = new Scanner(System.in);
  System.out.println("What is the radius of your circle: ");
  int r = in.nextInt();
  double radius =  r;

  int axis = (r*2)+4;
  int  sp = axis/2;
  double circumference = 2 * radius * Math.PI ;
  int c = (int)(Math.round(circumference)) ; 
  World.setVisible(true);
  World.setSize(axis,axis);
  World.setDelay(1);
  Robot a = new Robot(sp,sp, North,c);
  circlePath(a,r);
  circlePath2(a,r);
  circlePath3(a,r);
  circlePath4(a,r);
  a.putBeeper();
  a.turnLeft();
  a.turnLeft();
  for (int i=0;i<r;i++) 
    {
      a.move();
    }
  a.turnLeft();
  a.turnLeft();
  }

  public int circlePath(Robot a,int r)
  {
    for (int i=0;i<r;i++) 
    {
      a.move();
      System.out.println("up");
    }
    a.putBeeper();
    int ox = 0;
    int oy = r;
    int nx = 0;
    int ny = r;
    for (int i = 0; i<r; i++)
    {
      ny = oy-1;
      nx = squareRoot(ny,r);
      System.out.println(nx);
      System.out.println(ny);
      if (lastTurn == "N")
      { 
        turnRight(a);
        lastTurn = "E";
      }  
      if (lastTurn == "S")
      { 
        a.turnLeft();
        lastTurn = "E";
      }
      
      moveX(ox,nx,a);

      if (lastTurn == "E")
      { 
        turnRight(a);
        lastTurn = "S";
      }  
      
      moveY(oy,ny,a);

      a.putBeeper();
     oy=ny;
     ox=nx;
    }

    return(r);
  }
  public int circlePath2(Robot a,int r)
  {
    int ox = r;
    int oy = 0;
    int nx = r;
    int ny = 0;
    for (int i = 0; i<r; i++)
    {
      nx = ox-1;
      ny = squareRoot(nx,r);
      System.out.println("Circle 2");

      System.out.println(nx);
      System.out.println(ny);
      System.out.println(lastTurn);
      
      if (lastTurn == "N")
      { 
        turnRight(a);
        lastTurn = "E";
      }  
      if (lastTurn == "S")
      { 
        turnRight(a);
        lastTurn = "W";
      }
      
      moveX(ox,nx,a);

      if (lastTurn == "W")
      { 
        a.turnLeft();
        lastTurn = "S";
      }  
      
      moveY(oy,ny,a);

      a.putBeeper();
     oy=ny;
     ox=nx;
    }

    return(r);
  }

  public int circlePath3(Robot a,int r)
  {
    int ox = 0;
    int oy = -r;
    int nx = 0;
    int ny = -r;
    for (int i = 0; i<r; i++)
    {
      ny = oy+1;
      nx = squareRoot(ny,r);
      System.out.println(nx);
      System.out.println(ny);
      if (lastTurn == "N")
      { 
        a.turnLeft();
        lastTurn = "W";
      }  
      if (lastTurn == "S")
      { 
        turnRight(a);
        lastTurn = "W";
      }
      
      moveX(ox,nx,a);

      if (lastTurn == "W")
      { 
        turnRight(a);
        lastTurn = "N";
      }  
      
      moveY(oy,ny,a);

      a.putBeeper();
     oy=ny;
     ox=nx;
    }

    return(r);
  }

 public int circlePath4(Robot a,int r)
  {
    int ox = -r;
    int oy = 0;
    int nx = -r;
    int ny = 0;
    for (int i = 0; i<r; i++)
    {
      nx = ox+1;
      ny = squareRoot(nx,r);
      System.out.println("Circle 4");

      System.out.println(nx);
      System.out.println(ny);
      System.out.println(lastTurn);
      
      if (lastTurn == "N")
      { 
        turnRight(a);
        lastTurn = "E";
      }  
      
      moveX(ox,nx,a);

      if (lastTurn == "E")
      { 
        a.turnLeft();
        lastTurn = "N";
      }  
      
      moveY(oy,ny,a);

      a.putBeeper();
     oy=ny;
     ox=nx;
    }

    return(r);
  }
  public static void moveX(int ox, int nx,Robot a)
  {
    int steps =0;
    if (ox==nx)
    {
      return;
    }
    if (ox<nx) 
    {
      
      //turnRight(a);
      steps = nx-ox;
      System.out.println("*****");
      System.out.println(nx);
      System.out.println(ox);

      System.out.println(steps);
      for (int i = 0; i<steps; i++)
      {

        a.move();
        System.out.println("x:right");
        System.out.println(i);
        

      }
     System.out.println("---*****");

    }
    else 
    {

     //turnRight(a);
      steps = ox-nx;
      System.out.println("*****");
      System.out.println(nx);
      System.out.println(ox);

      System.out.println(steps);
      for (int i = 0; i<steps; i++)
      {

        a.move();
        System.out.println("x:right");
        System.out.println(i);
        

    }
  }
  }
  public static void moveY(int oy, int ny, Robot a)
  {  
    int steps =0;
    if (oy<ny) 
    {
      steps=ny-oy;
      for (int i = 0; i<steps; i++)
      {
        a.move();
      }
    }
    else 
    {
      steps=oy-ny;
      for (int i = 0; i<steps; i++)
      {
        a.move();
      }
    }
  }

  public int squareRoot(double yMove, double r)
  {
    double a = (r*r)-(yMove*yMove);
    double xMove = Math.sqrt(a);
    int x_move = (int) xMove;
    return(x_move);
  }
  public static void turnRight (Robot k)
  {
    k.turnLeft();
    k.turnLeft();
    k.turnLeft();
  }
}