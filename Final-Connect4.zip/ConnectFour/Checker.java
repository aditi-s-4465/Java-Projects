
public abstract class Checker {
	private boolean isRed;
	public Checker(boolean red) {
		isRed = red;
	}
	public  boolean isRed() { return isRed;}

}
