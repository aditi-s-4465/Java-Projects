
public class BlackChecker extends Checker {

	public BlackChecker() {
		super(false);
	}

}
