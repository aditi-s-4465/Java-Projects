import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;
import java.util.Scanner;


public class ConnectFourGame {
    
    private ConnectFourGrid grid = new ConnectFourGrid();
    private JFrame frame = new JFrame("Connect Four");
    private JPanel panel;
    private int player;
    
    public static void main(String[] args){
        new ConnectFourGame().start();
    }
    public void start() {
        setUpPanel();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

    }
    public void setUpPanel() {
        panel = new JPanel(){
            @Override
            public void paintComponent(Graphics g){
                super.paintComponent(g);
                grid.draw(g);
                drawGameInfo(g);
            }
        };
        panel.addMouseListener(new MouseInputAdapter(){
            @Override
            public void mousePressed(MouseEvent me){
              clickedAt(me);
            }
        });
        panel.setPreferredSize(new Dimension(1000, 1200));
        panel.setBackground(Color.black);
        frame.add(panel);
        frame.pack();


    }
    protected void clickedAt(MouseEvent me) {
        int x = me.getX()/40;
        int y = me.getY()/40;
        System.out.println("You just clicked at: "+x+", "+y);
        System.out.println("Do something with that info!!");
        grid.colClicked(x);
        frame.repaint();
        
    }
    /**
     * Who's turn is it?  How many Checkers played?  Who has won the most games?
     * @param g
     */
    protected void drawGameInfo(Graphics g) {
      g.setColor(Color.RED); // Changes the color of the Graphics “pen”
	    g.drawString("Red Wins: " + grid.getRedWins(), 320, 100); // draws the specified String at the specified location in current font
      
      g.setColor(Color.WHITE);
      g.drawString("Black Wins: " + grid.getBlackWins(), 320, 120);

      g.setColor(Color.PINK);
      g.drawString(grid.getRecentWin() , 320, 140);

      g.setColor(Color.ORANGE);
      g.drawString("BLACK IS ALWAYS THE NOT VERY SMART COMPUTER PLAYER", 320, 160);


	    //g.setFont(new Font("TimesRoman", Font.PLAIN, 20));//example of setting the font
      //Font​(String name, int style, int size) // constructor for a Font
    }

  /**
    * Reset the game so that it is ready to be played again.
    */
    public void resetGame(){
      grid.clearBoard();
      frame.repaint(); 


    }

}
