
public class RedChecker extends Checker {

	public RedChecker() {
		super(true);
	}

}
