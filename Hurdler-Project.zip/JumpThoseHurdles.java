import kareltherobot.*;

public class JumpThoseHurdles {
  // Find the hurdle with the max height!!
	// This is the Robot we will use to jump the hurdles
  // hurdler.frontIsClear() determines if it can take a step
	Robot hurdler = new Robot(1,1,Directions.East, 0);
	
	public static void main(String[] args) {
		new JumpThoseHurdles().start();
	}

	public void start() {
      loadWorld();
      int min=100;
      int max=0;
      int xPosition=1;
      while(true)
      {
        if (xPosition>20)
        {
          break;
        }
        int w = findHurdle(hurdler,xPosition);
        xPosition=xPosition+1;
        int h = climbHurdle(hurdler);
        if (h>max)
        {
          max = h;
        }
        if (h<min)
        {
          min = h;
        }
        hurdler.move();
        turnRight(hurdler);
        clearHurdle(h,hurdler);
        System.out.println("Max: "+max);
        System.out.println("Min: "+min);
        xPosition+=1;
      }
	}

	/**
	 * This method assumes the Robot is named hurdler and is facing East
	 * This moves hurdler to the next wall (hurdle). It returns the number
	 * of moves it took to get to the hurdle
	 */
	private int findHurdle(Robot hurdler, int pos) {
    int i = 0;
    int w = 0;
    int x=0;
    while (i==0)
    {
      if (x>30)
        {
          break;
        }
      if (hurdler.frontIsClear())
      {
          hurdler.move();
          x++;
          w++;
      }
      else
      {
          hurdler.turnLeft();
          break ; 
      }
    }
    return w;
	}
	/**
	 * This method assumes the Robot is named hurdler, is facing East and
	 * is at the base of the hurdle. 
	 * This moves the Robot to the top of the hurdle so that it can clear
	 * the wall.  
	 * @return The number of steps to get above the hurdle (height)
	 */
	private int climbHurdle(Robot hurdler) {
		int i = 0;
    int steps = 0;
    while (i==0)
    {
      turnRight(hurdler);
      if (hurdler.frontIsClear())
      {
         break;
      }
      else
      {
          hurdler.turnLeft();
          hurdler.move();
          steps++; 
      
      }
    }
		return steps;
	}

	/** 
	 * Moves the Robot (hurdler) over the wall and moves it to the ground so 
	 * that the Robot has its back to the hurdle and is facing the next one.
	 */
	private void clearHurdle(int x, Robot k) {
		// TODO Auto-generated method stub
		for (int i=0;i<x;i++)
    {
      k.move();
    }
    k.turnLeft();
	}

	private void loadWorld() {
		// line below "hardcodes" this to use one specific world
		// it would be better to ask the user...
		String worldName = "tester.world";
		World.readWorld(worldName);
		World.setVisible(true);
		World.setDelay(5);
	}
  public static void turnRight (Robot k)
  {
    k.turnLeft();
    k.turnLeft();
    k.turnLeft();
  }

}
