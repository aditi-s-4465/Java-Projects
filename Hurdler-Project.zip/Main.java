
public class Main {
  // Leave this alone!!
  public static void main(String[] args) {
    JumpThoseHurdles.main(null);
  }
}