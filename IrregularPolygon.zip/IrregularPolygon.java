import java.awt.geom.*;     // for Point2D.Double
import java.util.ArrayList; // for ArrayList
import gpdraw.*;            // for DrawingTool
import java.lang.Math;

public class IrregularPolygon{
  //instance variable(s)
  private ArrayList <Point2D.Double> myPolygon;
  private DrawingTool pencil;

  // constructors
  public IrregularPolygon() 
  { 
    pencil = new DrawingTool(new SketchPad(100, 100));
    this.myPolygon = new ArrayList<Point2D.Double>();
  }
  // public methods
  public void add(Point2D.Double aPoint)
  { 
    myPolygon.add(aPoint);
  }
  
  public void draw() 
  {
    pencil.up();
    pencil.move(myPolygon.get(0).getX(), myPolygon.get(0).getY());
    pencil.down();
    for(int i=0; i<myPolygon.size();i++)
   {
     pencil.move(myPolygon.get(i).getX(), myPolygon.get(i).getY());
   }
   pencil.move(myPolygon.get(0).getX(), myPolygon.get(0).getY());
  }
  
  public double perimeter() 
  { 
    double perimeter = 0;
    for(int i=0; i<myPolygon.size()-1;i++)
    {
      double x1 = myPolygon.get(i).getX();
      double y1 = myPolygon.get(i).getY();
      double x2 = myPolygon.get(i+1).getX();
      double y2 = myPolygon.get(i+1).getY();
      double x = x2-x1;
      double y = y2-y1;
      perimeter = perimeter + Math.sqrt((x*x)+(y*y));
    }
    double x1 = myPolygon.get(0).getX();
      double y1 = myPolygon.get(0).getY();
      double x2 = myPolygon.get(myPolygon.size()-1).getX();
      double y2 = myPolygon.get(myPolygon.size()-1).getY();
      double x = x2-x1;
      double y = y2-y1;
      perimeter = perimeter + Math.sqrt((x*x)+(y*y));

    return perimeter;
  }
  
  public double area()
  { 
    double x0 = myPolygon.get(0).getX();
    double y0 = myPolygon.get(0).getY();
    double area = 0; 

    for(int i=0; i<myPolygon.size()-1;i++)
    {
      area = area + (myPolygon.get(i).getX() * myPolygon.get(i+1).getY());
      System.out.println(myPolygon.get(i).getX()+ ","+myPolygon.get(i+1).getY());
    }

    area = area + (myPolygon.get(myPolygon.size()-1).getX()*y0);

    for(int i=0; i<myPolygon.size()-1;i++)
    {
      area = area - (myPolygon.get(i).getY() * myPolygon.get(i+1).getX());
      System.out.println(myPolygon.get(i+1).getX()+ ","+myPolygon.get(i).getY());
    }

    area = area - (myPolygon.get(myPolygon.size()-1).getY()*x0);

    area = 0.5 *area;

    return area;
  }
}
