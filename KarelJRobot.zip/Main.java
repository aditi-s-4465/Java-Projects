import javax.swing.*;
import java.awt.event.*;
import kareltherobot.*;

public class Main implements Directions{
  public static void main(String[] args) {
    Robot r = new Robot(1,1,North,100);
    int x = 7;
    World.setVisible(true);
		World.setSize(15, 15);
		World.setDelay(5);
    makeSquare(r,x);
  }
public static  void  makeSquare(Robot bob, int x)
{
 for (int i = 0; i<x ; i++)
 {
  bob.move();
  bob.putBeeper() ;
 }
 turnRight(bob);
 for (int i = 0; i<x ; i++)
 {
  bob.move();
  bob.putBeeper() ;
 }
turnRight(bob);
 for (int i = 0; i<x ; i++)
 {
  bob.move();
  bob.putBeeper() ;
 }
turnRight(bob);
 for (int i = 0; i<x ; i++)
 {
  bob.move();
  bob.putBeeper() ;
 }

}
public static void turnRight(Robot fred)
	{
		for(int i=0; i<3; i+=2)
		{
			fred.turnLeft();
		}
  }
}
//