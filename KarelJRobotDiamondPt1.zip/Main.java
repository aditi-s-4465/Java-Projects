import javax.swing.*;
import java.awt.event.*;
import java.util.Scanner;
import kareltherobot.*;

public class Main implements Directions{
  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    System.out.println("How many beepers do you want on each side of the diamond?");
    int a = in.nextInt();
    int b = a*2;
    int d = b/2;
    int e = a-1;
    int f = a-2;
    int g = (a*4); 
    Robot r = new Robot(d,1,North,g);
    World.setVisible(true);
    World.setSize(b,b);
    World.setDelay(1);
   for (int i= 0; i<e; i++) {
    turnRight(r);
    r.putBeeper();
    r.move(); 
    r.turnLeft();
    r.move();
    }
    r.putBeeper();
    r.putBeeper();
    r.turnLeft();
    r.turnLeft();
    r.move();
    r.turnLeft();
    r.move();
    r.putBeeper();
   for (int i= 0; i<f; i++) {
    turnRight(r);
    r.move();
    r.turnLeft();
    r.move();
    r.putBeeper(); 
   }
   r.turnLeft();
   r.turnLeft();
   for (int i= 0; i<e; i++) {
    r.turnLeft();
    r.move();
    turnRight(r);
    r.move();
    r.putBeeper(); 
   }
   r.putBeeper();
   r.move();
   turnRight(r);
   r.move();
   r.putBeeper();
   for (int i= 0; i<f; i++) {
    r.turnLeft();
    r.move();
    turnRight(r);
    r.move();
    r.putBeeper(); 
   }
  }
 public static void turnRight (Robot k)
  {
    k.turnLeft();
    k.turnLeft();
    k.turnLeft();
  }
}