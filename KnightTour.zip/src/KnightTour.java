import java.awt.*;
// TURN IN YOUR SCREENSHOTS
public class KnightTour{

  private int[][] board; // stores all the moves
  private int l;
  private int w;
  private int len = 8;
  private int wid = 8;
  static int moves;
  static int maxMoves=0;
  // more instance variables needed!!

public KnightTour()
{
  board = new int [len][wid];
  l=0;
  w=0;
  moves=0;
}

public static void main(String[] args){
    KnightTour kt = new KnightTour();
    int count=0;
    kt.runOnce();
    int tries = 1;
    while (moves<64)
   {
     kt.resetBoard();
     kt.runOnce();
     count ++;
     tries ++;
   //  if (count>=100000)
     //{
      // System.out.println("Could not get an answer even after 100000 tries. Sorry Mr.Sos :(");
     //  System.out.println("The maximum number of moves on the board that could be done is "+maxMoves);
     //  break;
    // }
    }
    System.out.println("It took "+tries+" tries");
    // run 10 tours and display average number of moves until trapped.
    // You need to create this method
    //kt.runSims(10);
  }

  public void runOnce(){
    this.setStartingLocation(2,1);// row 2, col 1
    int num = tour();
    //System.out.println("Knight got trapped after "+num+" moves.  Ending location was: "+"("+l+","+w+")");

  }
  // erase the last tour and set up variables so they are ready to make a new tour
  public void resetBoard(){
    for (int x = 0; x<len;x++)
  {
    for (int y=0; y<wid;y++)
    {
      board[x][y]=0;
    }

  }
  moves = 0;
  }
// This method sets the starting Location of the Knight
// Don't know where the info came from
  public void setStartingLocation(int row, int col){
    l = row;
    w = col;
    moves++;
    board[l][w]=moves;
  }
// visit locations on the board until trapped or tour is complete
// returns the number of locations visited.  There will be a loop in this method
  public int tour(){
    while (trapped()==false)
    {
      makeRandomMove();
    }
    if (moves>maxMoves)
    {
      maxMoves=moves;
      printBoard();
      System.out.println();
    }
    return moves;// there is a much better answer!!
  }
// Shift the board on the Graphics so it is not in the upper-lefthand corner of JPanel
  public void draw(Graphics g, int xShift, int yShift, int SQ){
    g.setColor(new Color(100, 120, 70));
    g.fillRect(xShift, yShift, SQ*8, SQ*8);
  }
  public void draw(Graphics g){
    this.draw(g, 0, 0, 80);
  }
  // displays the current state of the board to the console
  public void printBoard(){
    for (int a = 0; a<8;a++)
      {

        for (int b=0; b<8;b++)
        {
          System.out.print(board[a][b]+" ");
        }
      System.out.println();
      }

  }
  // Selects and moves the knight to a random location, if possible
  // Precondition:  The knight is not trapped when this method is called
  public void makeRandomMove(){
    // this will work in a couple of steps
      // 1. checks if trapped
      // 2. if not trapped, it goes through each position to see if it can move there
      // 3. if it can, it adds that to another 2d array where in column 0, it has the row of the position, and column 1 has the  position and each row holds the coordinate for a position. a 1 d array will also keep track of the number of rows filled
      // 4. once we go through all the possible positions, it will randomly choose a value from the 1d array. it will then go to that row, choose the row val and column val and move the knight over there. 
      //FINISHED
      //Turn in your screenshots
    int [][] positions = new int [8][2];
    int [] nums = new int[8];
    int x=0;

      if (l+2<8&&w+1<8&&board[l+2][w+1]==0)
      {
        positions[x][0]=l+2;
        positions[x][1]=w+1;
        nums[x]=x;
        x++;
      }
      if (l+2<8&&w-1>-1&&board[l+2][w-1]==0)
      {
        positions[x][0]=l+2;
        positions[x][1]=w-1;
        nums[x]=x;
        x++;
      }
      if (l-2>-1&&w+1<8&&board[l-2][w+1]==0)
      {
        positions[x][0]=l-2;
        positions[x][1]=w+1;
        nums[x]=x;
        x++;
      }
      if (l-2>-1&&w-1>-1&&board[l-2][w-1]==0)
      {
        positions[x][0]=l-2;
        positions[x][1]=w-1;
        nums[x]=x;
        x++;
      }
      if (l+1<8&&w+2<8&&board[l+1][w+2]==0)
      {
        positions[x][0]=l+1;
        positions[x][1]=w+2;
        nums[x]=x;
        x++;
      }
      if (l+1<8&&w-2>-1&&board[l+1][w-2]==0)
      {
        positions[x][0]=l+1;
        positions[x][1]=w-2;
        nums[x]=x;
        x++;
      }
      if (l-1>-1&&w+2<8&&board[l-1][w+2]==0)
      {
        positions[x][0]=l-1;
        positions[x][1]=w+2;
        nums[x]=x;
        x++;
      }
      if (l-1>-1&&w-2>-1&&board[l-1][w-2]==0)
      {
        positions[x][0]=l-1;
        positions[x][1]=w-2;
        nums[x]=x;
        x++;
      }

    int random = (int)(Math.random()*x);
    int a = positions[random][0];
    int b = positions[random][1];
    moves++;
    board[a][b]=moves;
   l =a;
   w = b;
  }
  // Selects and moves the knight to an optimal location which makes it 
  // more likely a complete tour will be accomplished
  // Precondition:  The knight is not trapped when this method is called
  public void makeBestMove(){


  }
  //determines if the knight is trapped (no unvisited squares available from current location)
  public boolean trapped(){
    if (l+2<8&&w+1<8&&board[l+2][w+1]==0)
    {
      return false;
    }
    else if (l+2<8&&w-1>-1&&board[l+2][w-1]==0)
    {
      return false;
    }
    else if (l-2>-1&&w+1<8&&board[l-2][w+1]==0)
    {
      return false;
    }
    else if (l-2>-1&&w-1>-1&&board[l-2][w-1]==0)
    {
      return false;
    }
    else if (l+1<8&&w+2<8&&board[l+1][w+2]==0)
    {
      return false;
    }
    else if (l+1<8&&w-2>-1&&board[l+1][w-2]==0)
    {
      return false;
    }
    else if (l-1>-1&&w+2<8&&board[l-1][w+2]==0)
    {
      return false;
    }
    else if (l-1>-1&&w-2>-1&&board[l-1][w-2]==0)
    {
      return false;
    }
    else
    {
      return true;
    }
  }

  public boolean thereIsZero()
  {
    for (int x = 0; x<8;x++)
  {
    for (int y=0; y<8;y++)
    {
     if (board[x][y]==0)
     {
       return true;
     }
    }
  }
  return false;
  }
  
}