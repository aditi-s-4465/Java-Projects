import kareltherobot.*;
import java.util.*;
public class Main implements Directions{
  // Leave this alone!!
  public static void main(String[] args) {
    new Main().start();
  }


  public void start(){
    /* prompt the user for the number of steps
     and height and tread of each step*/
    Scanner in = new Scanner(System.in);
    System.out.println("How many steps do you want: ");
    int steps = in.nextInt();
    System.out.println("What do you want the height of each step to be: ");
    int height = in.nextInt();
    System.out.println("How deep do you want each step to be:  ");
    int depth = in.nextInt();

    int a = steps*(height)+2;
    int b = steps*(depth)+2;
    int c = (height+depth)*steps;

    /* now write the code that makes the correct size World,
    a Robot with reasonable attributes.  */

    World.setVisible(true);
    World.setSize(a,b);
    World.setDelay(1);
    Robot r = new Robot(1,1,North,c+10);

    /* now direct the robot to make the steps correctly.
    This will require loops and functions.  Make appropriate methods.  I have provided one below.  You will make more (try to make at least 2 more)*/

    for (int x=0; x<steps; x++)
    {
      makeHeight(r,height);
      makeDepth(r,depth);
    }
    r.move();
    r.putBeeper();

  }
  // Robot rob is facing North, height beepers placed for the step
	public void makeHeight(Robot r, int height)
	{
		for (int i= 0; i<height; i++) 
    {
      r.putBeeper();
      r.move();
	  }
    r.putBeeper();
  }
  public void makeDepth(Robot r, int depth)
	{
    r.turnLeft();
    r.turnLeft();
    r.turnLeft();
		for (int i= 0; i<depth; i++) 
    {
      r.move();
      r.putBeeper();
	  }
     r.turnLeft();

  }
}