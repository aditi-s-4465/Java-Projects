class Main {
  public static void main(String[] args) {
   int min = 101;
   int max = 0;
   for(int i=0;i<11;i++)
   {
    int x=(int)(Math.random()*100.0);
    System.out.println(x);
    if (x>max)
    {
      max=x;
    }
    if (x<min)
    {
      min=x;
    }
   }
   System.out.print("Max is ");
   System.out.println(max);
   System.out.print("Min is ");
   System.out.println(min);
  }
}