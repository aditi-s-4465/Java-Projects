import java.util.*;
/**
 * Example1 Player will first play rock, then all scissors
 */
public class ShrivastavaAditi implements Player

{
    private static String name = "ShrivastavaAditi";
    private static String strategy = "If i lost, i put the option not played. If i win i play the loser's option";

    public String move(String [] myMoves, String [] opponentMoves, int myScore, int opponentScore)
    {
        int i=0;
        while (myMoves[i]!=null)
        {
          i++;
        }
        if (i==0)
        {
          return "p";
        }
        i--;
        if (opponentMoves[i].equals("p"))
        {
          if (myMoves[i].equals("p"))
          {
            return "r";
          }
          else if (myMoves[i].equals("r"))
          {
            return "s";
          }
          else if (myMoves[i].equals("s"))
          {
            return "p";
          }
          else 
          {
            return "p";
          }
        }
        else if (opponentMoves[i].equals("r"))
        {
          if (myMoves[i].equals("p"))
          {
            return "r";
          }
          else if (myMoves[i].equals("r"))
          {
            return "s";
          }
          else if (myMoves[i].equals("s"))
          {
            return "p";
          }
          else 
          {
            return "s";
          }
        }
        else if (opponentMoves[i].equals("s"))
        {
          if (myMoves[i].equals("p"))
          {
            return "r";
          }
          else if (myMoves[i].equals("r"))
          {
            return "s";
          }
          else if (myMoves[i].equals("s"))
          {
            return "p";
          }
          else 
          {
            return "p";
          }
        }
        else 
        {
          return "r";
        }
    }

    public String getName()
    {
        return name;
    }
}
