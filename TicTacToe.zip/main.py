import gspread
import random
import requests
import json


# SheetURL = https://docs.google.com/spreadsheets/d/1MwkZMDyD-w7L895S5iqW3tqlEfXWS1RIH_2rjp7jJ4s/edit#gid=0 

boardDisplay=[" ","X","O"]
moveRecord=["Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten"]
moveReverse={"Zero":0,"One":1,"Two":2,"Three":3,"Four":4,"Five":5,"Six":6,"Seven":7,"Eight":8,"Nine":9,"Ten":10}
winPerms=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]
playerLabels=["empty","me","opponent"]
cellLabels=["Cell 1","Cell 2","Cell 3","Cell 4","Cell 5","Cell 6","Cell 7","Cell 8","Cell 9"]

board=[0,0,0,0,0,0,0,0,0]
moves=[]
players=["random","random"]
boardHistory=[board.copy()]
activePlayer=1
gameStatus=0

#gc = gspread.service_account()
gc = gspread.service_account("./service_account.json")
sh = gc.open("tictactoe")

def reInit():
    global board,moves,activePlayer,gameStatus,boardHistory
    board=[0,0,0,0,0,0,0,0,0]
    moves=[]
    boardHistory=[board.copy()]
    activePlayer=1
    gameStatus=0

def getEmptyCells():
    l=[]
    for i in range(len(board)):
        #print("Now checking index",i)
        if(board[i]==0):
            l.append(i+1)
    return l

def getRandomEmptyCell():
    li=getEmptyCells()
    j=len(li)
    if(j<1):
        print("Sorry. No empty cells left. Len",j," in list",li," for board:",board)
    i=random.randint(1,j)
#    print("Found empty cell ref",i," from Len",j," in list",li," for board:",board)
    k=li[i-1]
#    print("Found empty cell",k," from Len",j," in list",li," for board:",board)
    return k

def getHumanInput():
    li=getEmptyCells()
    j=len(li)
    if(j<1):
        print("Sorry. No empty cells left. Len",j," in list",li," for board:",board)
    while True:
      n=int(input("Next move "+str(li)+": "))
      print("Human input is",n)
      if(n in li):
        return n
      print("Sorry. Not a valid input:",n,"; please choose from:",li)


def get_prediction(data={"Cell 1":"me","Cell 2":"me","Cell 3":"opponent","Cell 4":"opponent","Cell 5":"empty","Cell 6":"empty","Cell 7":"opponent","Cell 8":"me","Cell 9":"opponent"}):
  url = 'https://l47syleshe.execute-api.us-east-1.amazonaws.com/Predict/5f015f42-0d64-4eb8-aa09-709f87918669'
  r = requests.post(url, data=json.dumps(data))
  response = getattr(r,'_content').decode("utf-8")
  print(response)
  return response

def getAIInput():
  boardDict={}
  for i in range(9):
    if(board[i]==0):
      boardDict[cellLabels[i]]=playerLabels[0]
    elif(board[i]==activePlayer):
      boardDict[cellLabels[i]]=playerLabels[1]
    else:
      boardDict[cellLabels[i]]=playerLabels[2]
  #print("AI: About to send request",boardDict)
  j = get_prediction(boardDict)
  #print("AI: Got response",j)
  k1=json.loads(j)
  #print("AI: Got JSON object as as:",k1," from :",j)
  k2=k1["body"]
  #print("AI: parsed body as:",k2," from :",k1)
  k3=json.loads(k2)
  k4=k3["predicted_label"]
  #print("AI: parsed label as:",k4," from :",k2)
  l=moveReverse[k4]
  #print("AI: Sending back value ",l," for AI prediction:",k4)
  return l

def evaluateBoard():
    global gameStatus,winPerms,board
    for i in winPerms:
        j0=i[0]
        j1=i[1]
        j2=i[2]
        v=board[j0]
        if(v>0 and board[j1]==v and board[j2]==v):
           gameStatus=v
#    print("Returning gameStatus as ",gameStatus," with board as ",board," and activePlayer as",activePlayer)
    return gameStatus

def playCell(cellNumber):
    global activePlayer, boardHistory
    if(gameStatus != 0):
        print("Game is already over on board",board)
        return -2
    if(board[cellNumber-1] != 0):
        print("Invalid move. Cell",cellNumber,"is already occupied on board",board)
        return -1
    board[cellNumber-1]=activePlayer
    moves.append(cellNumber)
    boardHistory.append(board.copy())
    if activePlayer==1:
        activePlayer=2
    else:
        activePlayer=1
#    print("Played move on cell",cellNumber," ActivePlayer is now",activePlayer)
    return 1

def renderBoard():
    print("        TIC TAC TOE")
    print("Board: *-----------*")
    for i in (0,1,2):
        a=boardDisplay[board[i*3+0]]
        b=boardDisplay[board[i*3+1]]
        c=boardDisplay[board[i*3+2]]
        print("Board: |",a,"|",b,"|",c,"|")
    print("Board: *-----------*")
    if(gameStatus==0 and len(moves)==9):
        print("         DRAW!!")
    if(gameStatus==1):
        print("      X WON!!",moves)
    if(gameStatus==2):
        print("      O WON!!",moves)        
    print("\n\n")
    #print(boardHistory)

def playOneMove():
  currentPlayer=players[activePlayer-1]
  print("Current player is",currentPlayer)
  if(currentPlayer=="random"):
    nextCell=getRandomEmptyCell()
    return nextCell
  elif(currentPlayer=="human"):
    nextCell=getHumanInput()
    return nextCell
  elif(currentPlayer=="ai"):
    nextCell=getAIInput()
    return nextCell
  else:
    print("ERROR. Do not know player style",currentPlayer)
    nextCell=getRandomEmptyCell()
  return nextCell
  return    

def getGameType():
  global players
  x=-1
  while (x<0 or x>6):
    x=int(input("Game type (0=Random-Random, 1=R-Human, 2=H-R, 3=H-H, 4=H-AI, 5=AI-H, 6=AI-AI) :"))
    if(x<0 or x>6):
      print("Sorry - need a number between 0 and 6; you entered:",x)
  if(x==0):
    players=["random","random"]
  if(x==1):
    players=["random","human"]
  if(x==2):
    players=["human","random"]
  if(x==3):
    players=["human","human"]
  if(x==4):
    players=["human","ai"]
  if(x==5):
    players=["ai","human"]
  if(x==6):
    players=["ai","ai"]
  return
  

def playOneGame():
    reInit()
    getGameType()
    renderBoard()
    for i in range(9):
#        print("Playing move ",i)
        nc=playOneMove()
        playCell(nc)
        evaluateBoard()
        renderBoard()
        if(gameStatus!=0):
            return

def boardRender(gameStatus,moveValue,boardValue):
    renderBoard=[]
    for i in boardValue:
        if(i==0):
            renderBoard.append(playerLabels[0])
        elif(i==gameStatus):
            renderBoard.append(playerLabels[1])
        else:
            renderBoard.append(playerLabels[2])
    renderBoard.append(moveRecord[moveValue])
    return renderBoard

def recordOneGame():
    global sh,moves,boardHistory,gameStatus
    moveCount=len(moves)
    #print("Status=",gameStatus,"; movecount=",moveCount, " for moves=",moves,"\n boardHistory=",boardHistory)
    if(gameStatus==0): # Draw
        return
    #print("Appending data to Google Sheets")
    rowlist=[]
    for i in range(moveCount-1,-1,-2):
        #print("I=",i)
        moveValue=moves[i]
        boardValue=boardHistory[i]
        b=boardRender(gameStatus,moveValue,boardValue)
        #print("Appending move=",moveValue,",board=",boardValue,"render=",b)
        rowlist.append(b)
    sh.sheet1.append_rows(rowlist)
    return

while True:
    playOneGame()
    recordOneGame()

